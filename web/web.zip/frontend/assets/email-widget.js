jQuery(document).ready(function() {
	console.log('Thanks for reading WeeklyHow\'s Tutorials!');
});